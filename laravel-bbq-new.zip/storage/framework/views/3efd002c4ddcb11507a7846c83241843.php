<div class="card shadow">
    <div class="card-body">
        <center class="font-bold">Peserta Gelombang <?php echo e($gelombang_selected->nomor); ?> -
            <?php echo e($gelombang_selected->tahun_akademik); ?></center>

        <?php if($data->isEmpty()): ?>
            <button class="btn btn-block btn-outline-warning p-3">Data tidak ditemukan!</button>
        <?php else: ?>
            
            <input type="hidden" id="labelsData" value='<?php echo json_encode($labels, 15, 512) ?>'>
            <input type="hidden" id="jumlahData" value='<?php echo json_encode($jumlah, 15, 512) ?>'>
            <canvas id="chartjk" width="100%" height="100%"></canvas>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/dashboard/pie.blade.php ENDPATH**/ ?>