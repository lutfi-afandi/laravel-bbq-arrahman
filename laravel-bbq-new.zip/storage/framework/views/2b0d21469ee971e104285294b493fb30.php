

<?php $__env->startSection('content-header'); ?>
    <div class="container-fluid">


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-gradient-success">
                    <h4 class="card-title">Tambah Kelompok</h4>
                </div>
                <div class="card-body bg-success">
                    <form action="<?php echo e(route('admin.jadwal.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label class="text-center" for="pilihGelombang">Gelombang</label>
                                    <input type="hidden" name="gelombang_id" value="<?php echo e($informasi->gelombang_id); ?>">
                                    <select class="custom-select " name="gelombang1" id="pilihGelombang" disabled>
                                        <option value="">Gelombang
                                            <?php echo e($informasi->gelombang->nomor); ?> -
                                            <?php echo e($informasi->gelombang->tahun_akademik); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['gelombang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-sm-5">
                                <div class="form-group">
                                    <label class="text-center" for="tutor_id">Waktu</label>
                                    <select class="custom-select select2bs4" name="waktu_id" id="waktu_id" required>
                                        <option value="">Pilih Waktu</option>
                                        <?php $__currentLoopData = $waktus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waktu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($waktu->id); ?>"><?php echo e($waktu->hari); ?> - <?php echo e($waktu->jam); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['gelombang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="text-center" for="tutor_id">Tutor</label>
                                    <select class="custom-select select2bs4" name="tutor_id" id="tutor_id" required>
                                        <option value="">Pilih Tutor</option>
                                        <?php $__currentLoopData = $tutors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tutor->id); ?>"><i class="fa fa-user"></i>
                                                <?php echo e($tutor->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['gelombang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <span class="mt-1 ml-2">Gelombang</span>
                            <div class="col-sm-3 mb-1">
                                <select name="nomor" id="nomor" class="form-control">
                                    <option value="">pilih </option>
                                    <option <?php echo e($gelombang_selected->nomor == '1' ? 'selected' : ''); ?>>1</option>
                                    <option <?php echo e($gelombang_selected->nomor == '2' ? 'selected' : ''); ?>>2</option>
                                    <option <?php echo e($gelombang_selected->nomor == '3' ? 'selected' : ''); ?>>3</option>
                                </select>
                            </div>
                            <div class="col-sm-4 mb-1">
                                <select name="ta" id="ta" class="form-control">
                                    <option value="">pilih </option>
                                    <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            <?php echo e($gelombang_selected->tahun_akademik == $tahun->tahun_akademik ? 'selected' : ''); ?>>
                                            <?php echo e($tahun->tahun_akademik); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-paper-plane"></i>
                                submit
                            </button>


                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-gradient-maroon">
                    <h4 class="card-title"> Daftar Tutor BBQ <span class="badge bg-navy">Gelombang
                            <?php echo e($gelombang_selected->nomor); ?> - <?php echo e($gelombang_selected->tahun_akademik); ?></span>
                    </h4>
                </div>
                <div class="card-body">
                    <form action="" class="row">
                        <?php echo csrf_field(); ?>
                        <span class="mt-1 ml-2">Gelombang</span>
                        <div class="col-sm-3 mb-1">
                            <select name="nomor" id="nomor" class="form-control">
                                <option value="">pilih </option>
                                <option <?php echo e($gelombang_selected->nomor == '1' ? 'selected' : ''); ?>>1</option>
                                <option <?php echo e($gelombang_selected->nomor == '2' ? 'selected' : ''); ?>>2</option>
                                <option <?php echo e($gelombang_selected->nomor == '3' ? 'selected' : ''); ?>>3</option>
                            </select>
                        </div>
                        <div class="col-sm-3 mb-1">
                            <select name="ta" id="ta" class="form-control">
                                <option value="">pilih </option>
                                <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        <?php echo e($gelombang_selected->tahun_akademik == $tahun->tahun_akademik ? 'selected' : ''); ?>>
                                        <?php echo e($tahun->tahun_akademik); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-sm-2">
                            <button type="submit" class="btn btn-info"><i class="fa fa-filter"></i> filter</button>
                            <a href="<?php echo e(route('admin.jadwal.index')); ?>" class="btn btn-warning ml-1">
                                <i class="fa fa-sync-alt text-white"></i>
                            </a>
                        </div>
                    </form>

                    <hr>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-sm text-nowrap" width="100%" id="example1">
                            <thead class="bg-fuchsia">
                                <tr>
                                    <th width="5%" class="text-center">No</th>
                                    <th width="10%">Username</th>
                                    <th width="35%">Nama Tutor</th>
                                    <th width="10%">Jenis Kelamin</th>
                                    <th width="10%">Jadwal</th>
                                    <th>Peserta</th>
                                    <th class=" text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($jadwal->tutor->username); ?></td>
                                        <td><?php echo e($jadwal->tutor->name); ?></td>
                                        <td><?php echo e($jadwal->tutor->jenis_kelamin); ?></td>
                                        <td><?php echo e($jadwal->waktu->hari); ?> - <?php echo e($jadwal->waktu->jam); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.jadwal.show', $jadwal->id)); ?>"
                                                class="badge bg-success"><?php echo e($jadwal->kelompok->count() ?? '0'); ?> | peserta
                                            </a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.jadwal.destroy', $jadwal->id)); ?>" method="POST"
                                                class="form-delete d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger btn-xs btn-delete-jadwal"
                                                    data-id="<?php echo e($jadwal->id); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(function() {
            $('#example1').DataTable()
        });

        $('.select2').select2();

        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        });

        $('.btn-delete-jadwal').click(function(e) {
            e.preventDefault();
            let form = $(this).closest('form'); // Ambil form terkait
            let id = $(this).data('id'); // Ambil ID dari tombol

            Swal.fire({
                title: "Apakah Anda yakin?",
                text: "Jadwal ini akan dihapus secara permanen!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal"
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // Jika dikonfirmasi, submit form
                }
            });
        });
    </script>

    <?php if(session('swal_icon')): ?>
        <script>
            Swal.fire({
                icon: "<?php echo e(session('swal_icon')); ?>",
                title: "<?php echo e(session('swal_title')); ?>",
                text: "<?php echo e(session('swal_text')); ?>",
                timer: 3000,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>
    <?php if(session('toast_icon')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session('toast_icon')); ?>",
                title: "<?php echo e(session('toast_title')); ?>",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/jadwal/index.blade.php ENDPATH**/ ?>