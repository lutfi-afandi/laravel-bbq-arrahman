<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title ?? ''); ?></title>
</head>

<body>
    <h1><?php echo e($mahasiswa->nama); ?></h1>
</body>

</html>
<?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/peserta/index.blade.php ENDPATH**/ ?>