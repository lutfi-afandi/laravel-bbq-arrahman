


<?php $__env->startSection('content'); ?>
    <div class="card card-success card-outline">
        <div class="card-header">
            <h4 class="card-title">Kelompok :
                <span class="text-bold"><?php echo e($jadwal->tutor->name); ?>

                    [<?php echo e($jadwal->waktu->hari . ' - ' . $jadwal->waktu->jam); ?>]</span>
            </h4>
            <div class="card-tools">
                <a href="<?php echo e(route('admin.jadwal.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i>
                    kembali</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-sm text-nowrap" id="data-table">
                    <thead class="bg-gradient-success">
                        <tr>
                            <th class="text-center">#</th>
                            <th>NPM</th>
                            <th>Nama Lengkap</th>
                            <th>Jurusan - Kelas </th>
                            <th>Kelancaran</th>
                            <th>Jenis Kelamin</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php if($kelompoks->isEmpty()): ?>
                            <tr>
                                <th colspan="7" class="text-center bg-danger">- Belum Ada Data -</th>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $kelompoks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="" for="check">
                                    <th class="text-center"><?php echo e($loop->iteration); ?></th>
                                    <td class="align-middle"><?php echo e($kelompok->mahasiswa->npm); ?></td>
                                    <td class="align-middle"><?php echo e($kelompok->mahasiswa->nama); ?></td>
                                    <td class="align-middle"><?php echo e($kelompok->mahasiswa->jurusan->kode); ?> -
                                        <?php echo e($kelompok->mahasiswa->kelas->nama); ?>

                                    </td>
                                    <td class="align-middle"><?php echo e($kelompok->mahasiswa->kelancaran_mengaji); ?></td>
                                    <td class="align-middle"><?php echo e($kelompok->mahasiswa->jk); ?></td>
                                    <td class="align-middle">

                                        <form action="<?php echo e(route('admin.kelompok.destroy', $kelompok->id)); ?>" method="POST"
                                            class="form-delete d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-xs btn-delete-peserta"
                                                data-id="<?php echo e($kelompok->id); ?>">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <div class="card card-primary card-outline">
        <div class="card-header">
            <h4 class="card-title">Tambah Peserta</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.kelompok.store')); ?>" method="post" id="form-tambah">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="jadwal_id" value="<?php echo e($jadwal->id); ?>">
                <div class="table-responsive">
                    <table class="table table-striped table-sm text-nowrap" id="example1">
                        <thead class="bg-gradient-warning">
                            <tr>
                                <th class="text-center">#</th>
                                <th>NPM</th>
                                <th>Nama Lengkap</th>
                                <th>Jurusan - Kelas </th>
                                <th>Kelancaran</th>
                                <th>Jenis Kelamin</th>
                            </tr>
                        </thead>
                        <tbody class="">

                            <?php if($mahasiswas->isEmpty()): ?>
                                <tr>
                                    <th colspan="7" class="text-center bg-danger">- Belum Ada Data -</th>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="" for="check">
                                        <th class="text-center">

                                            <input style="" type="checkbox" id="check" name="mahasiswa_id[]"
                                                value="<?php echo e($mahasiswa->id); ?>">
                                        </th>
                                        <th class="align-middle"><?php echo e($mahasiswa->npm); ?></th>
                                        <td class="align-middle"><?php echo e($mahasiswa->nama); ?></td>
                                        <td class="align-middle"><?php echo e($mahasiswa->jurusan->kode); ?> -
                                            <?php echo e($mahasiswa->kelas->nama); ?>

                                        </td>
                                        <td class="align-middle"><?php echo e($mahasiswa->kelancaran_mengaji); ?></td>
                                        <td class="align-middle"><?php echo e($mahasiswa->jk); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-paper-plane"></i>
                                    Submit</button>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        // 
    </script>

    <script>
        $(document).ready(function() {
            $('#example1').DataTable();
            // Jika baris diklik, otomatis mencentang checkbox
            $("#example1 tbody tr").click(function(e) {
                // Abaikan jika klik pada input checkbox
                if ($(e.target).is("input[type=checkbox]")) return;

                let checkbox = $(this).find("input[type=checkbox]");
                checkbox.prop("checked", !checkbox.prop("checked")); // Toggle checkbox

                // Highlight baris jika checkbox dipilih
                $(this).toggleClass("table-success", checkbox.prop("checked"));
            });

        });

        $('.btn-delete-peserta').click(function(e) {
            e.preventDefault();
            let form = $(this).closest('form'); // Ambil form terkait
            let id = $(this).data('id'); // Ambil ID dari tombol

            Swal.fire({
                title: "Apakah Anda yakin?",
                text: "Data ini akan dihapus secara permanen!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal"
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // Jika dikonfirmasi, submit form
                }
            })
        });
    </script>

    <?php if(session('swal_icon')): ?>
        <script>
            Swal.fire({
                icon: "<?php echo e(session('swal_icon')); ?>",
                title: "<?php echo e(session('swal_title')); ?>",
                text: "<?php echo e(session('swal_text')); ?>",
                timer: 3000,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>
    <?php if(session('toast_icon')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session('toast_icon')); ?>",
                title: "<?php echo e(session('toast_title')); ?>",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/jadwal/show.blade.php ENDPATH**/ ?>