
<?php $__env->startSection('content-header'); ?>
    <form action="" class="row">
        <?php echo csrf_field(); ?>
        <span class="mt-1 ml-2">Gelombang</span>
        <div class="col-sm-1 mb-1">
            <select name="nomor" id="nomor" class="form-control">
                <option value="">pilih </option>
                <option <?php echo e($gelombang_selected->nomor == '1' ? 'selected' : ''); ?>>1</option>
                <option <?php echo e($gelombang_selected->nomor == '2' ? 'selected' : ''); ?>>2</option>
                <option <?php echo e($gelombang_selected->nomor == '3' ? 'selected' : ''); ?>>3</option>
            </select>
        </div>
        <div class="col-sm-3 mb-1">
            <select name="ta" id="ta" class="form-control">
                <option value="">pilih </option>
                <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($gelombang_selected->tahun_akademik == $tahun->tahun_akademik ? 'selected' : ''); ?>>
                        <?php echo e($tahun->tahun_akademik); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-3">
            <button type="submit" class="btn btn-info"><i class="fa fa-filter"></i> filter</button>
        </div>

    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card card-default">
        <div class="card-header bg-navy">
            <h3 class="card-title">
                <i class="fas fa-flag-checkered"></i>
                Laporan Kegiatan BBQ
            </h3>

        </div>
        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-sm text-nowrap" id="data-table">
                    <thead class="bg-gradient-success">
                        <tr>
                            <th class="text-center">#</th>
                            <th>Kelompok</th>
                            <th>Pertemuan Ke</th>
                            <th>Tanggal </th>
                            <th>Peserta</th>
                            <th>Hadir</th>
                            <th>Izin</th>
                            <th>Absen</th>
                            <th>Materi</th>
                            <th>Keterangan</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->iteration); ?></th>
                                <td> <span class="text-primary font-weight-bold"><?php echo e($laporan->jadwal->tutor->name); ?></span>
                                    <span class="font-italic"> - [<?php echo e($laporan->jadwal->waktu->hari); ?>,
                                        <?php echo e($laporan->jadwal->waktu->jam); ?>]</span>
                                </td>
                                <td><?php echo e($laporan->no_pertemuan); ?></td>
                                <td><?php echo e(indoDateFull($laporan->tanggal)); ?></td>
                                <td><?php echo e($laporan->jumlah_peserta); ?></td>
                                <td><?php echo e($laporan->hadir); ?></td>
                                <td><?php echo e($laporan->izin); ?></td>
                                <td><?php echo e($laporan->absen); ?></td>
                                <td><?php echo e($laporan->materi); ?></td>
                                <td><?php echo e($laporan->keterangan); ?></td>

                                <td>
                                    <a class="btn btn-xs btn-warning" target="_blank"
                                        href="<?php echo e(asset('storage/' . $laporan->foto)); ?>"><i class=" fa fa-file-image"></i>
                                    </a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('tutor.laporan.destroy', $laporan->id)); ?>" method="POST"
                                        class="form-delete d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-xs btn-delete-laporan"
                                            data-id="<?php echo e($laporan->id); ?>">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(function() {
            $('#data-table').DataTable()


        })

        $('.btn-delete-laporan').click(function(e) {
            e.preventDefault();
            let form = $(this).closest('form'); // Ambil form terkait
            let id = $(this).data('id'); // Ambil ID dari tombol

            Swal.fire({
                title: "Apakah Anda yakin?",
                text: "Data ini akan dihapus secara permanen!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal"
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // Jika dikonfirmasi, submit form
                }
            })
        });
    </script>

    <?php if(session('toast_icon')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session('toast_icon')); ?>",
                title: "<?php echo e(session('toast_title')); ?>",
            });
        </script>
    <?php endif; ?>

    <?php if(session('swal_icon')): ?>
        <script>
            Swal.fire({
                icon: "<?php echo e(session('swal_icon')); ?>",
                title: "<?php echo e(session('swal_title')); ?>",
                text: "<?php echo e(session('swal_text')); ?>",
                timer: 3000,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>