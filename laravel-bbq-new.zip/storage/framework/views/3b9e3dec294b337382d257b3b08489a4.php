

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-gradient-fuchsia">
                    <h4 class="card-title">Daftar Kegiatan</h4>
                    <div class="card-tools">
                        <button type="button" class="btn bg-gradient-yellow btn-sm text-white" data-toggle="modal"
                            data-target="#modal-default">
                            <i class="fa fa-plus"></i> Tambah Data
                        </button>
                    </div>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped" width="100%" id="tabel-kegiatan">
                            <thead class="bg-gradient-fuchsia">
                                <tr>
                                    <th class="text-center" width="3%">No</th>
                                    <th width="15%">Nama Kegiatan</th>
                                    <th width="60%">Deskripsi</th>
                                    <th width="7%">Foto</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th class="text-center"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($kegiatan->nama_kegiatan); ?></td>
                                        <td><?php echo e(Str::words($kegiatan->deskripsi, 30, '...')); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/kegiatan/' . $kegiatan->foto)); ?>" alt=""
                                                class="img img-thumbnail" style="20px">
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.kegiatan.destroy', $kegiatan->id)); ?>"
                                                method="POST" class="form-delete d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger btn-xs btn-delete-kegiatan"
                                                    data-id="<?php echo e($kegiatan->id); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-default">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title">Tambah Kegiatan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.kegiatan.store')); ?>" method="POST" id="form-kegiatan"
                    enctype="multipart/form-data">
                    <?php echo method_field('post'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="">Nama Kegiatan</label>
                            <input type="hidden" name="id" value="">
                            <input type="text" name="nama_kegiatan" class="form-control" id="nama_kegiatan" required>
                            <label for="">Deskripsi</label>
                            <textarea name="deskripsi" cols="30" rows="5" class="form-control" id="deskripsi" required></textarea>
                            <label for="">Foto Kegiatan</label>
                            <input type="file" name="foto" class="form-control" id="foto" accept="image/*"
                                required>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Simpan</button>
                    </div>
                </form>
                <div class="modal-footer justify-content-between">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(function() {
            $('#tabel-kegiatan').DataTable()

        });

        $('.btn-delete-kegiatan').click(function(e) {
            e.preventDefault();
            let form = $(this).closest('form'); // Ambil form terkait
            let id = $(this).data('id'); // Ambil ID dari tombol

            Swal.fire({
                title: "Apakah Anda yakin?",
                text: "Data ini akan dihapus secara permanen!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Ya, hapus!",
                cancelButtonText: "Batal"
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // Jika dikonfirmasi, submit form
                }
            });
        });
    </script>
    <?php if(session('swal_icon')): ?>
        <script>
            Swal.fire({
                icon: "<?php echo e(session('swal_icon')); ?>",
                title: "<?php echo e(session('swal_title')); ?>",
                text: "<?php echo e(session('swal_text')); ?>",
                timer: 3000,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>
    <?php if(session('toast_icon')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session('toast_icon')); ?>",
                title: "<?php echo e(session('toast_title')); ?>",
            });
        </script>
    <?php endif; ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/kegiatan/index.blade.php ENDPATH**/ ?>