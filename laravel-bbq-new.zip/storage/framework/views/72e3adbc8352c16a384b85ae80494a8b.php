
<?php $__env->startSection('content'); ?>
    <div class="card card-maroon card-outline">
        <div class="card-header">
            <h5 class="card-title">Kelompok Tutor : <?php echo e($jadwal->tutor->name); ?> </h5> &nbsp; <small
                class="text-success"><?php echo e($jadwal->waktu->hari); ?> - <?php echo e($jadwal->waktu->jam); ?> WIB
            </small>
            <div class="card-tools">
                <a href="<?php echo e(route('tutor.nilai.show', $jadwal->id)); ?>" class="btn bg-gradient-teal btn-sm"><i
                        class="fas fa-sort-amount-down"></i> Nilai</a>
                <a href="<?php echo e(route('tutor.absen.show', $jadwal->id)); ?>" class="btn btn-info btn-sm"><i
                        class="fas fa-clipboard"></i> Absen</a>
                <a href="/dashboard" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-sm text-nowrap" id="data-table">
                    <thead class="bg-gradient-success">
                        <tr>
                            <th class="text-center">#</th>
                            <th>NPM</th>
                            <th>Nama Lengkap</th>
                            <th>Kelas </th>
                            <th>Nomor WA</th>
                            <th>Kelancaran</th>
                            <th>Lunas</th>
                        </tr>
                    </thead>
                    <tbody class="">
                        <?php $__currentLoopData = $kelompoks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="">
                                <th class="text-center"><?php echo e($loop->iteration); ?></th>
                                <td class="align-middle"><?php echo e($kelompok->mahasiswa->npm); ?></td>
                                <td class="align-middle"><?php echo e($kelompok->mahasiswa->nama); ?></td>
                                <td class="align-middle"><?php echo e($kelompok->mahasiswa->jurusan->kode); ?> -
                                    <?php echo e($kelompok->mahasiswa->kelas->nama); ?></td>
                                <td class="align-middle">
                                    <a target="_blank"
                                        href="https://api.whatsapp.com/send?phone=62<?php echo e($kelompok->mahasiswa->nomor_wa); ?>&amp;text=Assalamu'alaikum, %0ASalam kenal, nama Saya *Reza Ashari*%0AKita satu kelompok BBQ %0AYuk berangkat BBQ 😁"
                                        class="badge badge-success ">
                                        <span class="text"><strong>+62 <?php echo e($kelompok->mahasiswa->nomor_wa); ?></strong>
                                        </span>
                                    </a>
                                </td>
                                <td class="align-middle"><?php echo e($kelompok->mahasiswa->kelancaran_mengaji); ?></td>
                                <td class="align-middle">
                                    <?php echo $kelompok->mahasiswa->keterangan == 'lunas'
                                        ? '<i class="fa fa-check-circle text-success"></i>'
                                        : '<i class="fa fa-times-circle text-danger"></i>'; ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/tutor/index.blade.php ENDPATH**/ ?>