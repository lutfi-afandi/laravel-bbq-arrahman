<div class="card shadow">
    <div class="card-body">
        <center class="font-bold">Peserta Gelombang <?php echo e($gelombang_selected->nomor); ?> -
            <?php echo e($gelombang_selected->tahun_akademik); ?> Per Prodi</center>

        <?php if(array_sum($jumlah) == 0): ?>
            <button class="btn btn-block btn-outline-warning p-3">Data tidak ditemukan!</button>
        <?php else: ?>
            
            <input type="hidden" id="labelsJurusanData" value='<?php echo json_encode($labels, 15, 512) ?>'>
            <input type="hidden" id="jumlahJurusanData" value='<?php echo json_encode($jumlah, 15, 512) ?>'>
            <canvas id="chartJurusan" width="1400px" height="400px"></canvas>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/dashboard/jurusan.blade.php ENDPATH**/ ?>