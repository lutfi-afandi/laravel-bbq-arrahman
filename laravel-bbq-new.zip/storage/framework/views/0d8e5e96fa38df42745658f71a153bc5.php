
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header bg-fuchsia">
            <h4 class="card-title">
                <i class="fa fa-print"></i> Cetak Laporan
            </h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-1 mr-0">Gelombang :</div>
                <div class="col-lg-1 mb-1">
                    <select name="nomor" id="nomor" class="form-control">
                        <option value="">pilih </option>
                        <option <?php echo e($gelombang_selected->nomor == '1' ? 'selected' : ''); ?>>1</option>
                        <option <?php echo e($gelombang_selected->nomor == '2' ? 'selected' : ''); ?>>2</option>
                        <option <?php echo e($gelombang_selected->nomor == '3' ? 'selected' : ''); ?>>3</option>
                    </select>
                </div>
                <div class="col-lg-2 mb-1">
                    <select name="ta" id="ta" class="form-control">
                        <option value="">pilih </option>
                        <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($gelombang_selected->tahun_akademik == $tahun->tahun_akademik ? 'selected' : ''); ?>>
                                <?php echo e($tahun->tahun_akademik); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4 mb-1">
                            <button type="button" class="btn btn-lg py-3 btn-block btn-primary"
                                onclick="export_mahasiswa()">
                                <i class="fa fa-print"></i> Cetak Nilai
                            </button>
                        </div>

                        <div class="col-lg-4 mb-1">
                            <button type="button" class="btn btn-lg py-3 btn-block bg-navy" onclick="export_tutor()">
                                <i class="fa fa-print"></i> Cetak Data Tutor
                            </button>
                        </div>

                        <div class="col-lg-4 mb-1">
                            <button type="button" class="btn btn-lg py-3 btn-block bg-gradient-maroon"
                                onclick="export_kelompok()">
                                <i class="fa fa-print"></i> Cetak Data Kelompok
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        function export_mahasiswa() {
            var nomor = $('#nomor').val();
            var ta = $('#ta').val();

            window.location.href = "/admin/exportMahasiswa?nomor=" + nomor + "&ta=" + ta;
        }

        function export_tutor() {
            var nomor = $('#nomor').val();
            var ta = $('#ta').val();

            window.location.href = "/admin/exportTutor?nomor=" + nomor + "&ta=" + ta;
        }

        function export_kelompok() {
            var nomor = $('#nomor').val();
            var ta = $('#ta').val();

            window.location.href = "/admin/exportKelompok?nomor=" + nomor + "&ta=" + ta;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/cetak/index.blade.php ENDPATH**/ ?>