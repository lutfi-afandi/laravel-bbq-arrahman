<div class="modal fade" tabindex="1" id="modal-masa">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header p-1 pl-3 pr-3 bg-gradient-teal">
                <h4 class="modal-title  text-center">TIMELINE PENDAFTARAN</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span></button>
            </div>
            <form method="post" action="<?php echo e(route('admin.informasi.masa', $informasi->id)); ?>">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Gelombang</label>
                        <select name="nomor" id="nomor" class="form-control">
                            <option value="1" <?php echo e($informasi->gelombang->nomor == '1' ? 'selected' : ''); ?>>1
                            </option>
                            <option value="2" <?php echo e($informasi->gelombang->nomor == '2' ? 'selected' : ''); ?>>2
                            </option>
                            <option value="3" <?php echo e($informasi->gelombang->nomor == '3' ? 'selected' : ''); ?>>3
                            </option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Tahun Ajaran</label>
                        <select name="tahun_akademik" id="tahun_akademik" class="form-control select2bs4">
                            <option value="">Pilih Tahun Ajar</option>
                            <?php $__currentLoopData = $tahuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tahun->tahun_akademik); ?>"
                                    <?php echo e($tahun->tahun_akademik == $informasi->gelombang->tahun_akademik ? 'selected' : ''); ?>>
                                    <?php echo e($tahun->tahun_akademik); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php
                            use Carbon\Carbon;
                            $mulai_daftar = Carbon::parse($informasi->mulai_daftar)->format('d/m/Y');
                            $akhir_daftar = Carbon::parse($informasi->akhir_daftar)->format('d/m/Y');
                        ?>
                        <label for="">Masa Pendaftaran </label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="far fa-calendar-alt"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control float-right" name="masa_daftar" id="masa_daftar"
                                value="<?php echo e($mulai_daftar); ?> - <?php echo e($akhir_daftar); ?>">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-info " type="submit">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\self-project\laravel-bbq-new\resources\views/admin/informasi/modal_masa.blade.php ENDPATH**/ ?>